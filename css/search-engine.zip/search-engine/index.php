<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Search Engine - Home</title>
<link href="search.css" type="text/css" rel="stylesheet" />
</head>
<body>
	<center>
		
		<img src="http://www.360websolution.com/images/logo2.png" style="margin-top:50px; margin-bottom:20px;" />
		<form action='./results.php' method='get'>
			<input type='text' name='input' size='50' class="sarch-field" /> 
			<input type='submit' value='Search 360' class="seach-button">
		</form>
	</center>
</body>
</html>